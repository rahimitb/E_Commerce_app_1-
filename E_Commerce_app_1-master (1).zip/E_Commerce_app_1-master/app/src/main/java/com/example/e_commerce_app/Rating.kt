package com.example.e_commerce_app

data class Rating(
    val count: Int,
    val rate: Double
)