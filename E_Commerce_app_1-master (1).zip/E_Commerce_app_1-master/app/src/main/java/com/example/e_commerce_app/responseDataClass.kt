package com.example.e_commerce_app

class responseDataClass : ArrayList<responseDataClassItem>()