package com.example.e_commerce_app

data class Product(
    val id: Int,
    val image: Int,
    val title: String,
    val description: String
)